
def compute_square():
    n = int(input('Enter your number :'))
    return n ** 2

